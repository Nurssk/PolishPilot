function q(e,i,t={}){const r={...t,id:t.id??`${Date.now()}-${Math.random().toString(36).slice(2)}`,timestamp:t.timestamp??Date.now(),stage:e,message:i,htmlPreview:t.htmlPreview?s(c(t.htmlPreview),4e3):void 0,cssPreview:t.cssPreview?s(d(t.cssPreview),8e3):void 0,outputHtml:t.outputHtml?s(c(t.outputHtml),8e3):void 0,outputCss:t.outputCss?s(d(t.outputCss),8e3):void 0,warnings:t.warnings?.slice(0,20),errors:t.errors?.slice(0,20)};return S(r),r}function Y(e,i){return[...e??[],...i].slice(-100)}function J(e){return e.map(i=>({...i,htmlPreview:s(c(i.htmlPreview??""),4e3),cssPreview:s(d(i.cssPreview??""),8e3),outputHtml:s(c(i.outputHtml??""),8e3),outputCss:s(d(i.outputCss??""),8e3)}))}function s(e,i=4e3){return e?e.length<=i?e:`${e.slice(0,i)}

/* truncated: ${e.length-i} chars omitted */`:""}function c(e){return e.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi,"<script>[removed]<\/script>").replace(/\son\w+="[^"]*"/gi,"").replace(/\son\w+='[^']*'/gi,"").replace(/\son\w+=([^\s>]+)/gi,"").replace(/javascript:/gi,"blocked-javascript:")}function d(e){return e.replace(/url\([\s\S]*?\)/gi,"url([removed])").replace(/@import[^;]+;/gi,"/* @import removed */")}function S(e){P()&&(console.groupCollapsed(`[Design Humanizer Preview] ${e.stage}`),console.log(e.summary??{}),e.htmlPreview&&console.log("HTML:",e.htmlPreview),e.cssPreview&&console.log("CSS:",e.cssPreview),e.outputHtml&&console.log("Output HTML:",e.outputHtml),e.outputCss&&console.log("Output CSS:",e.outputCss),e.warnings?.length&&console.warn(e.warnings),e.errors?.length&&console.error(e.errors),console.groupEnd())}function P(){try{return!!import.meta.env?.DEV||globalThis.localStorage?.getItem("DH_PREVIEW_DEBUG")==="1"}catch{return!1}}function Q(e){const i=e.pattern.layoutPreviewType,t=R(e.content.items),r=`
<section class="polishpilot-preview-root polishpilot-preview-section polishpilot-pattern-${V(i)}" style="${M(e.styleTokens)}">
  ${D(e.content,e.styleTokens)}
  ${T(i,t,e.styleTokens)}
  ${F(e.content,e.styleTokens)}
</section>`;return{html:r,layoutCss:L(),debug:{patternId:e.pattern.id,patternName:e.pattern.name,rendererUsed:f(i),preservedClassCount:A(e.content),inlineFallbackUsed:!!e.styleTokens,generatedNodeCount:N(r)}}}function R(e){return e.length?e.slice(0,6):[{id:"fallback-1",title:"Card 1",description:"Extracted preview item"},{id:"fallback-2",title:"Card 2",description:"Extracted preview item"},{id:"fallback-3",title:"Card 3",description:"Extracted preview item"}]}function D(e,i){return!e.sectionEyebrow&&!e.sectionTitle&&!e.sectionSubtitle?"":`<div class="polishpilot-preview-header">
    ${e.sectionEyebrow?`<div class="polishpilot-preview-eyebrow" style="${b(i)}">${o(e.sectionEyebrow)}</div>`:""}
    ${e.sectionTitle?`<h2 class="polishpilot-preview-heading" style="${m(i)}">${o(e.sectionTitle)}</h2>`:""}
    ${e.sectionSubtitle?`<p class="polishpilot-preview-subtitle" style="${a(i,!0)}">${o(e.sectionSubtitle)}</p>`:""}
  </div>`}function T(e,i,t){return`<div class="polishpilot-preview-grid ${f(e)}">
    ${i.slice(0,6).map((n,l)=>j(n,l,e,t)).join(`
`)}
  </div>`}function j(e,i,t,r){const n=B(i,t),l=`polishpilot-preview-card${n?" polishpilot-preview-card-featured":""}`;return t==="pricing-emphasis"?z(e,i,l,r):t==="metric-bento"||t==="hero-metric-support-stats"||t==="stats-highlight"?H(e,l,r):`<article class="${l}" style="${v(r,n)}">
    ${e.icon?.exists?U(r):""}
    ${e.eyebrow?`<div class="polishpilot-preview-card-eyebrow" style="${b(r)}">${o(e.eyebrow)}</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${w(r)}">${o(e.title)}</h3>
    ${e.description?`<p class="polishpilot-preview-card-text" style="${a(r,!0)}">${o(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${g(r)}">${o(e.cta)}</div>`:""}
  </article>`}function z(e,i,t,r){const n=i===1;return`<article class="${t}${n?" polishpilot-preview-card-featured":""}" style="${v(r,n)}">
    ${n?`<div class="polishpilot-preview-badge" style="${g(r)}">Recommended</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${w(r)}">${o(e.title)}</h3>
    ${e.value?`<div class="polishpilot-preview-price" style="${m(r)}">${o(e.value)}</div>`:""}
    ${e.description?`<p class="polishpilot-preview-card-text" style="${a(r,!0)}">${o(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${g(r)}">${o(e.cta)}</div>`:""}
  </article>`}function H(e,i,t){return`<article class="${i}" style="${v(t)}">
    <div class="polishpilot-preview-stat-value" style="${m(t)}">${o(e.value??e.title)}</div>
    <div class="polishpilot-preview-stat-label" style="${a(t,!0)}">${o(e.value?e.title:e.description??"")}</div>
  </article>`}function U(e){return`<div class="polishpilot-preview-icon-placeholder" style="${K(e)}">·</div>`}function F(e,i){return!e.outsideText.length||E(e)?"":`<div class="polishpilot-preview-outside-text">
    ${e.outsideText.map(t=>`<p style="${a(i,!0)}">${o(t)}</p>`).join(`
`)}
  </div>`}function E(e){return!!(e.sectionEyebrow||e.sectionTitle||e.sectionSubtitle||e.items.length)}function f(e){return e==="bento-grid"?"polishpilot-preview-bento-grid":e==="featured-side-stack"?"polishpilot-preview-featured-side-stack":e==="center-highlight"?"polishpilot-preview-center-highlight":e==="workflow-feature-grid"||e==="step-flow"?"polishpilot-preview-step-grid":e==="pricing-emphasis"?"polishpilot-preview-pricing-grid":e==="split-hero"||e==="split-cta"?"polishpilot-preview-split-grid":e==="hero-product-preview"?"polishpilot-preview-product-preview-grid":e==="form-benefits-sidebar"?"polishpilot-preview-form-grid":e==="metric-bento"||e==="hero-metric-support-stats"?"polishpilot-preview-metric-grid":"polishpilot-preview-generic-grid"}function B(e,i){return e===0&&["bento-grid","featured-side-stack","center-highlight","hero-product-preview","metric-bento","hero-metric-support-stats"].includes(i)}function A(e){return[...e.rootClasses??[],...e.sectionTitleSourceClasses??[],...e.sectionSubtitleSourceClasses??[],...e.items.flatMap(i=>[...i.sourceClasses??[],...i.titleSourceClasses??[],...i.textSourceClasses??[],...i.buttonSourceClasses??[]])].length}function N(e){return e.match(/<([a-z][a-z0-9-]*)\b/gi)?.length??0}function M(e){const i=y(e?.section.padding,"48px");return p({background:e?.section.background,color:e?.section.color,"font-family":e?.section.fontFamily,padding:i,"--pp-section-bg":e?.section.background,"--pp-text":e?.heading.color??e?.section.color,"--pp-muted":e?.body.color,"--pp-card-bg":e?.card.background,"--pp-border":e?.card.borderColor,"--pp-radius":e?.card.borderRadius,"--pp-shadow":e?.card.boxShadow,"--pp-section-padding":i,"--pp-accent-color":e?.accentColor})}function m(e){return p({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":u(e?.heading.fontSize,24,56,"36px"),"font-weight":e?.heading.fontWeight,"line-height":"1.08","letter-spacing":e?.heading.letterSpacing})}function w(e){return p({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":u(e?.body.fontSize??e?.heading.fontSize,14,22,"16px"),"font-weight":e?.heading.fontWeight})}function a(e,i=!1){return p({color:i?e?.muted.color??e?.body.color:e?.body.color,"font-size":u(e?.body.fontSize,12,18,"14px"),"line-height":"1.45"})}function v(e,i=!1){return p({background:e?.card.background,border:i&&e?.accentColor?`1px solid ${e.accentColor}`:e?.card.border,"border-color":i?e?.accentColor??e?.card.borderColor:e?.card.borderColor,"border-radius":e?.card.borderRadius,"box-shadow":e?.card.boxShadow,padding:y(e?.card.padding,"24px")})}function g(e){return p({background:e?.button.background??e?.accentColor,color:e?.button.color,border:e?.button.border,"border-radius":e?.button.borderRadius,padding:e?.button.padding,"font-weight":e?.button.fontWeight})}function b(e){return p({color:e?.accentColor})}function K(e){return p({color:e?.accentColor,"border-color":e?.accentColor})}function L(){return`
.polishpilot-preview-root,
.polishpilot-preview-section {
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: var(--pp-section-padding, 48px);
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column;
  justify-content: center;
  position: relative !important;
  opacity: 1 !important;
  visibility: visible !important;
  background: var(--pp-section-bg, #ffffff);
  color: var(--pp-text, #111827);
}
.polishpilot-preview-header {
  max-width: 760px;
  margin-bottom: clamp(18px, 4%, 32px);
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-heading,
.polishpilot-preview-subtitle,
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-outside-text p {
  margin: 0;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-subtitle {
  margin-top: 12px;
  max-width: 760px;
}
.polishpilot-preview-eyebrow,
.polishpilot-preview-card-eyebrow {
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 800;
  font-size: 12px;
}
.polishpilot-preview-grid {
  display: grid !important;
  gap: clamp(12px, 2.4%, 20px);
  min-height: 0;
}
.polishpilot-preview-card {
  min-width: 0;
  overflow: hidden !important;
  border-style: solid;
  border-width: 1px;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
  position: relative !important;
  background: var(--pp-card-bg, #ffffff);
  color: var(--pp-text, #111827);
  border-color: var(--pp-border, #e5e7eb);
  border-radius: var(--pp-radius, 16px);
  box-shadow: var(--pp-shadow, none);
}
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-stat-label,
.polishpilot-preview-outside-text p {
  overflow-wrap: anywhere;
}
.polishpilot-preview-card-text {
  margin-top: 10px;
}
.polishpilot-preview-card-cta,
.polishpilot-preview-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-top: 16px;
}
.polishpilot-preview-badge {
  margin-top: 0;
  margin-bottom: 14px;
}
.polishpilot-preview-icon-placeholder {
  width: 36px;
  height: 36px;
  border: 2px solid var(--pp-accent-color, currentColor);
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 14px;
  opacity: 0.75;
}
.polishpilot-preview-outside-text {
  display: grid;
  gap: 10px;
  margin-top: 28px;
  max-width: 820px;
}
.polishpilot-preview-bento-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-bento-grid .polishpilot-preview-card-featured {
  grid-column: span 2;
  grid-row: span 2;
}
.polishpilot-preview-featured-side-stack,
.polishpilot-preview-metric-grid {
  grid-template-columns: 1.35fr 0.85fr;
}
.polishpilot-preview-featured-side-stack .polishpilot-preview-card:first-child,
.polishpilot-preview-metric-grid .polishpilot-preview-card:first-child {
  grid-row: span 2;
}
.polishpilot-preview-center-highlight {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-center-highlight .polishpilot-preview-card:first-child {
  grid-column: 1 / -1;
  max-width: 78%;
  justify-self: center;
}
.polishpilot-preview-step-grid,
.polishpilot-preview-pricing-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-split-grid,
.polishpilot-preview-form-grid,
.polishpilot-preview-product-preview-grid {
  grid-template-columns: 0.9fr 1.1fr;
  align-items: center;
}
.polishpilot-preview-generic-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-price,
.polishpilot-preview-stat-value {
  margin-top: 16px;
  font-size: clamp(28px, 4vw, 48px);
  line-height: 1;
  font-weight: 900;
}
.polishpilot-preview-stat-label {
  margin-top: 10px;
}
@media (max-width: 768px) {
  .polishpilot-preview-root,
  .polishpilot-preview-section {
    padding: 28px;
  }
  .polishpilot-preview-grid,
  .polishpilot-preview-bento-grid,
  .polishpilot-preview-featured-side-stack,
  .polishpilot-preview-center-highlight,
  .polishpilot-preview-step-grid,
  .polishpilot-preview-pricing-grid,
  .polishpilot-preview-split-grid,
  .polishpilot-preview-form-grid,
  .polishpilot-preview-product-preview-grid,
  .polishpilot-preview-metric-grid,
  .polishpilot-preview-generic-grid {
    grid-template-columns: 1fr;
  }
  .polishpilot-preview-bento-grid .polishpilot-preview-card-featured,
  .polishpilot-preview-center-highlight .polishpilot-preview-card:first-child {
    grid-column: auto;
    grid-row: auto;
    max-width: none;
  }
}`}function u(e,i,t,r){const n=Number.parseFloat(e??"");return Number.isFinite(n)?`${Math.max(i,Math.min(t,n))}px`:r}function y(e,i){const t=e?.split(/\s+/).filter(Boolean);return t?.length?t.slice(0,4).map(r=>u(r,10,36,i)).join(" "):i}function p(e){return Object.entries(e).filter(i=>!!i[1]).map(([i,t])=>`${i}: ${W(t)};`).join(" ")}function o(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function V(e){return o(e).replace(/'/g,"&#39;")}function W(e){return e.replace(/[<>"']/g,"")}function X(e){const i=e.aiResult?.sectionType??e.capture?.detected.sectionType??"unknown",t=e.aiResult?.layoutType??e.capture?.detected.layoutType??"unknown",r=e.aiResult?.currentLayoutProblem||"The selected section needs stronger layout hierarchy and spacing.",n=_(e.capture),l=e.aiResult?.detectedKeywords?.join(", ")||"unknown",h=e.aiResult?.uiProblems?.join(", ")||r,x=e.templateReference?`${e.templateReference.title} (${e.templateReference.url})`:"none",$=e.animationReference?`${e.animationReference.title} (${e.animationReference.url})`:"none",C=k(e.uncodixify,e.includedUncodixifyRuleIds);return`You are working in a React + Next.js + Tailwind CSS project.
Refactor the selected UI section using this layout pattern:
${e.pattern.name}

Design Humanizer context:
Section type: ${i}
Current layout: ${t}
Current issue: ${r}
Detected keywords: ${l}
UI problems: ${h}
Selected layout pattern: ${e.pattern.name}
Selected template reference: ${x}
Selected animation idea: ${$}

Instructions:
1. Keep existing content, props, data mapping, links, API calls and business logic.
2. Do not remove any existing content.
3. Preserve the component API.
4. Improve visual hierarchy and spacing.
5. Use responsive Tailwind CSS.
6. Keep mobile layout clean and single-column when needed.
7. Add subtle hover states and accessible focus-visible states.
8. Do not add unnecessary dependencies.
9. Return the updated component code only.
10. Keep the same content. Change layout, hierarchy, spacing, and arrangement only.
11. Use the selected template/reference only as high-level inspiration.
12. Do not copy exact code, assets, text, logos, or branding from references.
13. Preserve card radius, background, shadow, and style direction where possible.
14. If animation is selected, add subtle accessible motion and respect prefers-reduced-motion.

Pattern direction:
${e.pattern.promptInstruction}

Reference direction:
${G(e.templateReference)}

Animation direction:
${I(e.animationReference)}

Tailwind hint:
${e.pattern.tailwindHint}

Visual style direction:
${n}${C}`}function k(e,i){if(!e||!e.findings.length)return"";const t=i?new Set(i):null,r=e.findings.filter(l=>!t||t.has(l.ruleId));return r.length?`

## Uncodixify design cleanup rules

The selected UI has these AI-like/Codex-like issues:

${r.map((l,h)=>O(l,h+1)).join(`

`)}

Follow these rules:
- avoid generic AI SaaS styling;
- avoid decorative gradients and glow;
- keep UI functional and clean;
- use project colors;
- preserve existing content;
- do not rewrite text unless necessary;
- do not change functionality.`:""}function O(e,i){const t=e.evidence[0]??"Detected during analysis.";return`${i}. ${e.title}
Evidence: ${t}
Fix: ${e.recommendation}`}function G(e){return e?`Use ${e.title} from ${e.source} only as high-level visual inspiration.
Category: ${e.category}
Tags: ${e.tags.join(", ")}
Usage note: ${e.usageNote}`:"No external template reference selected."}function I(e){return e?`Use ${e.title} from ${e.source} as motion inspiration only.
Category: ${e.category}
Tags: ${e.tags.join(", ")}
Best for: ${e.bestFor}
Avoid when: ${e.avoidWhen}
Respect prefers-reduced-motion and avoid heavy motion.`:"No animation reference selected."}function _(e){const i=e?.styleTokens;if(i)return`Preserve the existing visual style:
- Section background: ${i.section.background??"existing section background"}
- Text color: ${i.section.color??i.heading.color??"existing text color"}
- Muted text color: ${i.muted.color??i.body.color??"existing muted text color"}
- Card background: ${i.card.background??"existing card background"}
- Border: ${i.card.border??i.card.borderColor??"existing border treatment"}
- Border radius: ${i.card.borderRadius??"existing radius"}
- Shadow: ${i.card.boxShadow??"existing shadow treatment"}
- Button background: ${i.button.background??"existing button background"}
- Button radius: ${i.button.borderRadius??"existing button radius"}
- Font family: ${i.section.fontFamily??i.heading.fontFamily??"existing font family"}

Use these as style direction, not as forced values if they conflict with the project's design system. Do not paste extracted CSS wholesale; preserve the visual language through the existing component and design tokens.`;const t=e?.styleContext;return t?`Preserve the current visual style using these as direction, not exact forced values if they conflict with the existing design system:
- Theme: ${t.theme}
- Background: ${t.section.backgroundColor??"existing section background"}
- Card background: ${t.card.backgroundColor??"existing card background"}
- Text color: ${t.text.headingColor??t.section.color??"existing text color"}
- Muted text color: ${t.text.mutedColor??t.text.bodyColor??"existing muted text color"}
- Accent color: ${t.accent.color??t.accent.backgroundColor??"existing accent color"}
- Border radius: ${t.card.borderRadius??t.section.borderRadius??"existing radius"}
- Shadow: ${t.card.boxShadow??"existing shadow treatment"}`:"Preserve the existing visual style from the component and design system."}export{c as a,Q as b,q as c,Y as d,J as e,X as g,d as s,s as t};
