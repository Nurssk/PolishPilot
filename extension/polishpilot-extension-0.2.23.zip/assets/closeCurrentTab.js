function o(){try{chrome.tabs.getCurrent(e=>{e?.id!=null?chrome.tabs.remove(e.id):window.close()})}catch{window.close()}}export{o as c};
