import{r as s,j as t,c as F}from"./client.js";import{c as R,t as S,s as z,a as E,b as H,d as I,g as U}from"./generateCursorPrompt.js";import{F as C}from"./messages.js";function T({html:e,usedCssText:r="",layoutCss:i="",title:u="Humanized preview",viewportWidth:a=800,viewportHeight:c=420,debug:d=!1,onDebugLog:g,onRenderInfoChange:y}){const n=s.useRef(null),[l,j]=s.useState({width:a,height:c}),h=Math.max(.1,Math.min(l.width/a,l.height/c)),f=s.useMemo(()=>B({html:e,usedCssText:r,layoutCss:i,title:u,viewportWidth:a,viewportHeight:c,scale:h,debug:d}),[d,e,i,h,u,r,c,a]),o=s.useMemo(()=>({readyState:"pending",htmlLength:e.length,usedCssLength:r.length,layoutCssLength:i.length,totalDocumentLength:f.length,renderedFrameWidth:l.width,renderedFrameHeight:l.height,scale:h}),[l.height,l.width,e.length,i.length,h,f.length,r.length]);s.useEffect(()=>{y?.(o)},[y,o]),s.useEffect(()=>{const b=n.current;if(!b)return;const x=b;function v(){const N=x.getBoundingClientRect();N.width<=0||N.height<=0||j(k=>{const L=Math.round(N.width),P=Math.round(N.height);return k.width===L&&k.height===P?k:{width:L,height:P}})}v();const w=new ResizeObserver(v);return w.observe(x),window.addEventListener("resize",v),()=>{w.disconnect(),window.removeEventListener("resize",v)}},[]),s.useEffect(()=>{d&&g?.(R("iframe-render","Preview iframe document injected",{summary:{htmlLength:e.length,usedCssLength:r.length,layoutCssLength:i.length,totalDocumentLength:f.length,viewportWidth:a,viewportHeight:c,renderedFrameWidth:l.width,renderedFrameHeight:l.height,scale:h},htmlPreview:S(E(e),4e3),cssPreview:S(z(`${r}

${$(d)}

${i}`),8e3)}))},[d,l.height,l.width,e,i,g,h,f,r,c,a]);function m(){let b="loaded",x;try{b=n.current?.contentDocument?.readyState??"loaded"}catch(w){x=w instanceof Error?w.message:String(w)}const v={...o,readyState:b,error:x};y?.(v),d&&g?.(R("iframe-render","Preview iframe loaded",{summary:v,warnings:x?[x]:[]}))}return t.jsx("iframe",{className:"h-full w-full border-0 bg-white",onLoad:m,ref:n,sandbox:"",srcDoc:f,title:u})}function B({html:e,usedCssText:r,layoutCss:i,title:u,viewportWidth:a,viewportHeight:c,scale:d,debug:g}){return`<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${K(u)}</title>
    <style>
      :root {
        color-scheme: light dark;
      }
      * {
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
      }
      body {
        background: transparent;
      }
      .dh-preview-document {
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
      }
      .dh-preview-viewport {
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
      }
      .dh-preview-canvas {
        width: ${Math.max(1,Math.round(a))}px;
        height: ${Math.max(1,Math.round(c))}px;
        overflow: hidden;
        transform: scale(${d.toFixed(6)});
        transform-origin: top left;
      }
      ${D(r)}
      ${$(g)}
      ${D(i)}
      ${$(g)}
    </style>
  </head>
  <body>
    <div class="dh-preview-document">
      <div class="dh-preview-viewport">
        <div class="dh-preview-canvas">
          ${O(e)}
        </div>
      </div>
    </div>
  </body>
</html>`}function O(e){return e.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,"").replace(/\son[a-z]+\s*=\s*(".*?"|'.*?'|[^\s>]+)/gi,"").replace(/\s(?:href|src)\s*=\s*(['"])\s*javascript:[\s\S]*?\1/gi,"")}function D(e){return e.replace(/<\/style/gi,"<\\/style").replace(/@import[^;]+;/gi,"").replace(/url\(\s*(['"]?)\s*javascript:[^)]+\)/gi,"none")}function $(e){return`
html,
body {
  margin: 0 !important;
  padding: 0 !important;
  width: 100% !important;
  height: 100% !important;
  overflow: hidden !important;
  background: #ffffff;
  color: #111827;
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}
* {
  box-sizing: border-box;
}
.dh-preview-document,
.dh-preview-viewport,
.dh-preview-canvas {
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-root {
  display: flex !important;
  opacity: 1 !important;
  visibility: visible !important;
  min-height: 100% !important;
  background: var(--pp-section-bg, #ffffff);
  color: var(--pp-text, #111827);
  font-family: inherit;
  ${e?"outline: 2px dashed rgba(14, 165, 233, 0.35);":""}
}
.polishpilot-preview-section,
.polishpilot-preview-header,
.polishpilot-preview-grid,
.polishpilot-preview-card,
.polishpilot-preview-heading,
.polishpilot-preview-subtitle,
.polishpilot-preview-card-title,
.polishpilot-preview-card-text {
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-section {
  position: relative !important;
}
.polishpilot-preview-grid {
  display: grid !important;
}
.polishpilot-preview-card {
  display: block !important;
  background: var(--pp-card-bg, #ffffff);
  color: var(--pp-text, #111827);
  border: 1px solid var(--pp-border, #e5e7eb);
  border-radius: var(--pp-radius, 16px);
  box-shadow: var(--pp-shadow, none);
  padding: 24px;
}
.polishpilot-preview-icon-placeholder {
  display: inline-flex !important;
}
`}function K(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function _(){const[e,r]=s.useState(null),[i,u]=s.useState(""),[a,c]=s.useState(null),d=s.useRef(""),g=s.useRef("");s.useEffect(()=>{chrome.storage.session.get(C).then(o=>{r(o[C]??null)}).catch(()=>r(null))},[]);async function y(){if(!e?.pattern)return;const o=U({pattern:e.pattern,aiResult:e.aiResult,capture:e.capture,designDirectionSelected:!0,templateReference:e.templateReference,animationReference:e.animationReference});await navigator.clipboard.writeText(o),u("Copied."),window.setTimeout(()=>u(""),1800)}const n=s.useMemo(()=>e?.pattern&&e.previewContent?H({pattern:e.pattern,content:e.previewContent,styleTokens:e.capture?.styleTokens}):null,[e]),l=A(e?.capture),j={aspectRatio:`${l.width} / ${l.height}`},h=s.useCallback(o=>{r(m=>{if(!m?.capture)return m;const b={...m.capture,previewDebugLogs:I(m.capture.previewDebugLogs,[o])},x={...m,capture:b};return chrome.storage.session.set({[C]:x}),x})},[]);s.useEffect(()=>{if(!e?.pattern||!e.previewContent||!n)return;const o=`${e.captureId??"none"}:${e.pattern.id}:html-generation`;d.current!==o&&(d.current=o,h(R("html-generation","Humanized preview HTML/CSS generated",{summary:{patternId:e.pattern.id,patternName:e.pattern.name,rendererUsed:n.debug?.rendererUsed,preservedClassCount:n.debug?.preservedClassCount,inlineFallbackUsed:n.debug?.inlineFallbackUsed,generatedNodeCount:n.debug?.generatedNodeCount},outputHtml:S(E(n.html),8e3),outputCss:S(z(n.layoutCss),8e3)})))},[h,n,e]);const f=s.useCallback(o=>{const m=`${e?.captureId??"none"}:${e?.pattern.id??"none"}:${o.stage}`;g.current!==m&&(g.current=m,h(o))},[h,e?.captureId,e?.pattern.id]);return t.jsxs("main",{className:"min-h-screen bg-pilot-bg text-pilot-text",children:[t.jsxs("header",{className:"border-b border-pilot-border bg-pilot-panel/90 px-8 py-5 backdrop-blur",children:[t.jsxs("div",{className:"mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3",children:[t.jsxs("div",{children:[t.jsx("h1",{className:"text-xl font-black tracking-tight",children:"Design Humanizer Preview"}),t.jsx("p",{className:"mt-1 text-sm text-pilot-muted",children:e?.pattern.name??"No selected pattern"})]}),t.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[t.jsx("button",{className:"dh-button-primary px-4 py-2 text-sm",disabled:!e?.pattern||!e.capture,onClick:()=>{y()},type:"button",children:"Copy Cursor Prompt"}),t.jsx("button",{className:"dh-button-secondary px-4 py-2 text-sm",onClick:()=>window.close(),type:"button",children:"Close"})]})]}),i?t.jsx("p",{className:"mx-auto mt-2 max-w-7xl text-xs font-semibold text-pilot-primaryDeep",children:i}):null]}),t.jsx("section",{className:"px-8 py-8",children:t.jsx("div",{className:"dh-card-elevated mx-auto max-w-[1440px] p-6",children:e&&n?t.jsxs("div",{className:"grid gap-5 xl:grid-cols-2",children:[t.jsxs("section",{className:"min-w-0",children:[t.jsxs("div",{className:"mb-3 flex items-center justify-between gap-3",children:[t.jsx("h2",{className:"text-sm font-black text-pilot-text",children:"Original screenshot"}),t.jsx("span",{className:"dh-chip px-2 py-1 text-[11px]",children:e.capture?.selectedRect?`${Math.round(e.capture.selectedRect.width)} x ${Math.round(e.capture.selectedRect.height)}`:"captured area"})]}),t.jsx("div",{className:"flex w-full items-center justify-center overflow-hidden rounded-xl border border-pilot-border bg-pilot-bg/70",style:j,children:e.capture?.screenshotBase64?t.jsx("img",{alt:"Original selected UI area",className:"h-full w-full object-contain",src:W(e.capture.screenshotBase64)}):t.jsx("p",{className:"text-sm text-pilot-muted",children:"No screenshot found."})})]}),t.jsxs("section",{className:"min-w-0",children:[t.jsxs("div",{className:"mb-3 flex flex-wrap items-center justify-between gap-3",children:[t.jsxs("div",{children:[t.jsx("h2",{className:"text-sm font-black text-pilot-text",children:"Humanized live preview"}),t.jsx("p",{className:"mt-1 text-xs text-pilot-muted",children:"Isolated iframe using extracted CSS plus style-token fallback."})]}),e.mode==="developer"&&e.capture?t.jsxs("div",{className:"flex flex-wrap gap-2 text-[11px] font-bold text-pilot-muted",children:[t.jsxs("span",{className:"dh-chip px-2 py-1",children:["Used CSS rules: ",e.capture.usedCssRules?.ruleCount??0]}),t.jsxs("span",{className:"dh-chip px-2 py-1",children:["Skipped stylesheets: ",e.capture.usedCssRules?.skippedStyleSheets??0]}),t.jsxs("span",{className:"dh-chip px-2 py-1",children:["Style token fallback: ",e.capture.styleTokens?"enabled":"missing"]})]}):null]}),t.jsx("div",{className:"w-full overflow-hidden rounded-xl border border-pilot-border bg-white shadow-2xl shadow-black/25",style:j,children:t.jsx(T,{debug:e.mode==="developer",html:n.html,layoutCss:n.layoutCss,onDebugLog:f,onRenderInfoChange:c,usedCssText:e.capture?.usedCssRules?.cssText,viewportHeight:l.height,viewportWidth:l.width})}),e.mode==="developer"?t.jsx(q,{builtHtmlLength:n.html.length,cssRuleCount:e.capture?.usedCssRules?.ruleCount??0,iframeRenderInfo:a,patternId:e.pattern.id,previewContent:e.previewContent}):null]})]}):t.jsx("div",{className:"flex min-h-[600px] items-center justify-center rounded-xl border border-pilot-border bg-pilot-bg/60 p-8 text-center",children:t.jsxs("div",{children:[t.jsx("h2",{className:"text-lg font-black text-pilot-text",children:"No preview data found"}),t.jsx("p",{className:"mt-2 text-sm leading-6 text-pilot-muted",children:"Return to the side panel, select a layout pattern, then open the full preview again."})]})})})})]})}function W(e){return e.startsWith("data:")?e:`data:image/png;base64,${e}`}function q({builtHtmlLength:e,cssRuleCount:r,iframeRenderInfo:i,patternId:u,previewContent:a}){const c=a.items.map(d=>d.title).filter(Boolean).join(", ");return t.jsxs("div",{className:"mt-3 rounded-xl border border-pilot-border bg-pilot-bg/70 p-3 text-[11px] leading-5 text-pilot-muted",children:[t.jsx("div",{className:"mb-2 font-black uppercase tracking-wide text-pilot-primaryDeep",children:"Preview debug"}),t.jsxs("div",{className:"grid gap-x-4 gap-y-1 md:grid-cols-2",children:[t.jsx(p,{label:"previewContent",value:a?"yes":"no"}),t.jsx(p,{label:"pattern id",value:u}),t.jsx(p,{label:"sectionTitle",value:a.sectionTitle??"none"}),t.jsx(p,{label:"sectionSubtitle",value:a.sectionSubtitle??"none"}),t.jsx(p,{label:"items count",value:String(a.items.length)}),t.jsx(p,{label:"item titles",value:c||"none"}),t.jsx(p,{label:"iframe readyState",value:i?.readyState??"pending"}),t.jsx(p,{label:"html length",value:String(i?.htmlLength??e)}),t.jsx(p,{label:"css rules count",value:String(r)}),t.jsx(p,{label:"frame",value:i?`${i.renderedFrameWidth} x ${i.renderedFrameHeight}`:"pending"}),t.jsx(p,{label:"scale",value:i?i.scale.toFixed(3):"pending"}),t.jsx(p,{label:"render error",value:i?.error??"none"})]})]})}function p({label:e,value:r}){return t.jsxs("div",{className:"min-w-0",children:[t.jsxs("span",{className:"font-black text-pilot-soft",children:[e,": "]}),t.jsx("span",{className:"break-words text-pilot-text",children:r})]})}function A(e){const r=Math.max(1,Math.round(e?.selectedRect.width??800)),i=Math.max(1,Math.round(e?.selectedRect.height??420));return{width:r,height:i}}const M=document.getElementById("root");M&&F.createRoot(M).render(t.jsx(s.StrictMode,{children:t.jsx(_,{})}));
