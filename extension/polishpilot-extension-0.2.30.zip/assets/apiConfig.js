const o="https://polish-pilot.vercel.app";function r(t){const s=t.startsWith("/")?t:`/${t}`;return`${o}${s}`}export{o as A,r as a};
