function et(e,t,i={}){const r={...i,id:i.id??`${Date.now()}-${Math.random().toString(36).slice(2)}`,timestamp:i.timestamp??Date.now(),stage:e,message:t,htmlPreview:i.htmlPreview?w(P(i.htmlPreview),4e3):void 0,cssPreview:i.cssPreview?w(T(i.cssPreview),8e3):void 0,outputHtml:i.outputHtml?w(P(i.outputHtml),8e3):void 0,outputCss:i.outputCss?w(T(i.outputCss),8e3):void 0,warnings:i.warnings?.slice(0,20),errors:i.errors?.slice(0,20)};return Z(r),r}function tt(e,t){return[...e??[],...t].slice(-100)}function it(e){return e.map(t=>({...t,htmlPreview:w(P(t.htmlPreview??""),4e3),cssPreview:w(T(t.cssPreview??""),8e3),outputHtml:w(P(t.outputHtml??""),8e3),outputCss:w(T(t.outputCss??""),8e3)}))}function w(e,t=4e3){return e?e.length<=t?e:`${e.slice(0,t)}

/* truncated: ${e.length-t} chars omitted */`:""}function P(e){return e.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi,"<script>[removed]<\/script>").replace(/\son\w+="[^"]*"/gi,"").replace(/\son\w+='[^']*'/gi,"").replace(/\son\w+=([^\s>]+)/gi,"").replace(/javascript:/gi,"blocked-javascript:")}function T(e){return e.replace(/url\([\s\S]*?\)/gi,"url([removed])").replace(/@import[^;]+;/gi,"/* @import removed */")}function Z(e){ee()&&(console.groupCollapsed(`[Design Humanizer Preview] ${e.stage}`),console.log(e.summary??{}),e.htmlPreview&&console.log("HTML:",e.htmlPreview),e.cssPreview&&console.log("CSS:",e.cssPreview),e.outputHtml&&console.log("Output HTML:",e.outputHtml),e.outputCss&&console.log("Output CSS:",e.outputCss),e.warnings?.length&&console.warn(e.warnings),e.errors?.length&&console.error(e.errors),console.groupEnd())}function ee(){try{return!!import.meta.env?.DEV||globalThis.localStorage?.getItem("DH_PREVIEW_DEBUG")==="1"}catch{return!1}}const W=new Set(["metric-bento","hero-metric-support-stats","stats-highlight","analytics-overview","metric-trend-grid","stats-story-band"]),te=new Set(["plan-comparison-table","comparison-spec-table","comparison-matrix"]),ie=new Set(["split-hero","split-cta","product-detail-split","checkout-summary-split","case-study-split","demo-panel-cta","before-after-hero","hero-dashboard-preview","hero-video-demo","hero-contained-card","hero-off-grid-visual"]),re=new Set(["form-benefits-sidebar","split-auth-proof","onboarding-checklist-form","profile-settings-form"]);function rt(e){const t=e.pattern.layoutPreviewType,i=oe(e.content.items),r=`
<section class="polishpilot-preview-root polishpilot-preview-section polishpilot-pattern-${ve(t)}" style="${fe(e.styleTokens)}">
  ${se(e.content,e.styleTokens)}
  ${ne(t,i,e.styleTokens)}
  ${de(e.content,e.styleTokens)}
</section>`;return{html:r,layoutCss:we(),debug:{patternId:e.pattern.id,patternName:e.pattern.name,rendererUsed:q(t),preservedClassCount:ge(e.content),inlineFallbackUsed:!!e.styleTokens,generatedNodeCount:me(r)}}}function oe(e){return e.length?e.slice(0,6):[{id:"fallback-1",title:"Card 1",description:"Extracted preview item"},{id:"fallback-2",title:"Card 2",description:"Extracted preview item"},{id:"fallback-3",title:"Card 3",description:"Extracted preview item"}]}function se(e,t){return!e.sectionEyebrow&&!e.sectionTitle&&!e.sectionSubtitle?"":`<div class="polishpilot-preview-header">
    ${e.sectionEyebrow?`<div class="polishpilot-preview-eyebrow" style="${O(t)}">${p(e.sectionEyebrow)}</div>`:""}
    ${e.sectionTitle?`<h2 class="polishpilot-preview-heading" style="${L(t)}">${p(e.sectionTitle)}</h2>`:""}
    ${e.sectionSubtitle?`<p class="polishpilot-preview-subtitle" style="${k(t,!0)}">${p(e.sectionSubtitle)}</p>`:""}
  </div>`}function ne(e,t,i){return`<div class="polishpilot-preview-grid ${q(e)}">
    ${t.slice(0,6).map((o,s)=>ae(o,s,e,i)).join(`
`)}
  </div>`}function ae(e,t,i,r){const o=he(t,i),s=`polishpilot-preview-card${o?" polishpilot-preview-card-featured":""}`;return i==="pricing-emphasis"?ce(e,t,s,r):W.has(i)?le(e,s,r):`<article class="${s}" style="${H(r,o)}">
    ${e.icon?.exists?pe(r):""}
    ${e.eyebrow?`<div class="polishpilot-preview-card-eyebrow" style="${O(r)}">${p(e.eyebrow)}</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${G(r)}">${p(e.title)}</h3>
    ${e.description?`<p class="polishpilot-preview-card-text" style="${k(r,!0)}">${p(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${j(r)}">${p(e.cta)}</div>`:""}
  </article>`}function ce(e,t,i,r){const o=t===1;return`<article class="${i}${o?" polishpilot-preview-card-featured":""}" style="${H(r,o)}">
    ${o?`<div class="polishpilot-preview-badge" style="${j(r)}">Recommended</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${G(r)}">${p(e.title)}</h3>
    ${e.value?`<div class="polishpilot-preview-price" style="${L(r)}">${p(e.value)}</div>`:""}
    ${e.description?`<p class="polishpilot-preview-card-text" style="${k(r,!0)}">${p(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${j(r)}">${p(e.cta)}</div>`:""}
  </article>`}function le(e,t,i){return`<article class="${t}" style="${H(i)}">
    <div class="polishpilot-preview-stat-value" style="${L(i)}">${p(e.value??e.title)}</div>
    <div class="polishpilot-preview-stat-label" style="${k(i,!0)}">${p(e.value?e.title:e.description??"")}</div>
  </article>`}function pe(e){return`<div class="polishpilot-preview-icon-placeholder" style="${be(e)}">·</div>`}function de(e,t){return!e.outsideText.length||ue(e)?"":`<div class="polishpilot-preview-outside-text">
    ${e.outsideText.map(i=>`<p style="${k(t,!0)}">${p(i)}</p>`).join(`
`)}
  </div>`}function ue(e){return!!(e.sectionEyebrow||e.sectionTitle||e.sectionSubtitle||e.items.length)}function q(e){return e==="bento-grid"?"polishpilot-preview-bento-grid":e==="featured-side-stack"?"polishpilot-preview-featured-side-stack":e==="center-highlight"?"polishpilot-preview-center-highlight":e==="workflow-feature-grid"||e==="step-flow"||e==="demo-steps-hero"?"polishpilot-preview-step-grid":e==="pricing-emphasis"||e==="pricing-toggle"?"polishpilot-preview-pricing-grid":te.has(e)?"polishpilot-preview-comparison-grid":ie.has(e)?"polishpilot-preview-split-grid":e==="hero-product-preview"?"polishpilot-preview-product-preview-grid":re.has(e)?"polishpilot-preview-form-grid":W.has(e)?"polishpilot-preview-metric-grid":e==="activity-feed-sidebar"||e==="table-summary-rail"||e==="faq-sidebar"?"polishpilot-preview-sidebar-grid":e==="kanban-board"?"polishpilot-preview-kanban-grid":e==="settings-detail-pane"||e==="sidebar-app-shell"?"polishpilot-preview-app-shell-grid":e==="magic-link-panel"||e==="card-cta"||e==="hero-email-capture"||e==="hero-image-background"?"polishpilot-preview-centered-panel-grid":e==="command-center-nav"||e==="mega-menu-topbar"?"polishpilot-preview-nav-stack":e==="footer-link-hub"?"polishpilot-preview-footer-grid":e==="product-card-grid"||e==="resource-card-grid"||e==="quote-wall"?"polishpilot-preview-card-grid":e==="changelog-timeline"?"polishpilot-preview-timeline-grid":e==="feature-tabs"||e==="hero-tabs-preview"?"polishpilot-preview-tabs-grid":e==="integration-logo-grid"||e==="hero-logo-cloud"?"polishpilot-preview-logo-grid":e==="editorial-feature-stack"?"polishpilot-preview-editorial-stack":"polishpilot-preview-generic-grid"}function he(e,t){return e===0&&["bento-grid","featured-side-stack","center-highlight","hero-product-preview","metric-bento","hero-metric-support-stats","analytics-overview","product-detail-split","before-after-hero","quote-wall","case-study-split","stats-story-band"].includes(t)}function ge(e){return[...e.rootClasses??[],...e.sectionTitleSourceClasses??[],...e.sectionSubtitleSourceClasses??[],...e.items.flatMap(t=>[...t.sourceClasses??[],...t.titleSourceClasses??[],...t.textSourceClasses??[],...t.buttonSourceClasses??[]])].length}function me(e){return e.match(/<([a-z][a-z0-9-]*)\b/gi)?.length??0}function fe(e){const t=K(e?.section.padding,"48px");return v({background:e?.section.background,color:e?.section.color,"font-family":e?.section.fontFamily,padding:t,"--pp-section-bg":e?.section.background,"--pp-text":e?.heading.color??e?.section.color,"--pp-muted":e?.body.color,"--pp-card-bg":e?.card.background,"--pp-border":e?.card.borderColor,"--pp-radius":e?.card.borderRadius,"--pp-shadow":e?.card.boxShadow,"--pp-section-padding":t,"--pp-accent-color":e?.accentColor})}function L(e){return v({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":N(e?.heading.fontSize,24,56,"36px"),"font-weight":e?.heading.fontWeight,"line-height":"1.08","letter-spacing":e?.heading.letterSpacing})}function G(e){return v({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":N(e?.body.fontSize??e?.heading.fontSize,14,22,"16px"),"font-weight":e?.heading.fontWeight})}function k(e,t=!1){return v({color:t?e?.muted.color??e?.body.color:e?.body.color,"font-size":N(e?.body.fontSize,12,18,"14px"),"line-height":"1.45"})}function H(e,t=!1){return v({background:e?.card.background,border:t&&e?.accentColor?`1px solid ${e.accentColor}`:e?.card.border,"border-color":t?e?.accentColor??e?.card.borderColor:e?.card.borderColor,"border-radius":e?.card.borderRadius,"box-shadow":e?.card.boxShadow,padding:K(e?.card.padding,"24px")})}function j(e){return v({background:e?.button.background??e?.accentColor,color:e?.button.color,border:e?.button.border,"border-radius":e?.button.borderRadius,padding:e?.button.padding,"font-weight":e?.button.fontWeight})}function O(e){return v({color:e?.accentColor})}function be(e){return v({color:e?.accentColor,"border-color":e?.accentColor})}function we(){return`
.polishpilot-preview-root,
.polishpilot-preview-section {
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: var(--pp-section-padding, 48px);
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column;
  justify-content: center;
  position: relative !important;
  opacity: 1 !important;
  visibility: visible !important;
  background: var(--pp-section-bg, #ffffff);
  color: var(--pp-text, #111827);
}
.polishpilot-preview-header {
  max-width: 760px;
  margin-bottom: clamp(18px, 4%, 32px);
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-heading,
.polishpilot-preview-subtitle,
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-outside-text p {
  margin: 0;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-subtitle {
  margin-top: 12px;
  max-width: 760px;
}
.polishpilot-preview-eyebrow,
.polishpilot-preview-card-eyebrow {
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 800;
  font-size: 12px;
}
.polishpilot-preview-grid {
  display: grid !important;
  gap: clamp(12px, 2.4%, 20px);
  min-height: 0;
}
.polishpilot-preview-card {
  min-width: 0;
  overflow: hidden !important;
  border-style: solid;
  border-width: 1px;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
  position: relative !important;
  background: var(--pp-card-bg, #ffffff);
  color: var(--pp-text, #111827);
  border-color: var(--pp-border, #e5e7eb);
  border-radius: var(--pp-radius, 16px);
  box-shadow: var(--pp-shadow, none);
}
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-stat-label,
.polishpilot-preview-outside-text p {
  overflow-wrap: anywhere;
}
.polishpilot-preview-card-text {
  margin-top: 10px;
}
.polishpilot-preview-card-cta,
.polishpilot-preview-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-top: 16px;
}
.polishpilot-preview-badge {
  margin-top: 0;
  margin-bottom: 14px;
}
.polishpilot-preview-icon-placeholder {
  width: 36px;
  height: 36px;
  border: 2px solid var(--pp-accent-color, currentColor);
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 14px;
  opacity: 0.75;
}
.polishpilot-preview-outside-text {
  display: grid;
  gap: 10px;
  margin-top: 28px;
  max-width: 820px;
}
.polishpilot-preview-bento-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-bento-grid .polishpilot-preview-card-featured {
  grid-column: span 2;
  grid-row: span 2;
}
.polishpilot-preview-featured-side-stack,
.polishpilot-preview-metric-grid {
  grid-template-columns: 1.35fr 0.85fr;
}
.polishpilot-preview-featured-side-stack .polishpilot-preview-card:first-child,
.polishpilot-preview-metric-grid .polishpilot-preview-card:first-child {
  grid-row: span 2;
}
.polishpilot-preview-center-highlight {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-center-highlight .polishpilot-preview-card:first-child {
  grid-column: 1 / -1;
  max-width: 78%;
  justify-self: center;
}
.polishpilot-preview-step-grid,
.polishpilot-preview-pricing-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-comparison-grid {
  grid-template-columns: 0.9fr repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-split-grid,
.polishpilot-preview-form-grid,
.polishpilot-preview-product-preview-grid {
  grid-template-columns: 0.9fr 1.1fr;
  align-items: center;
}
.polishpilot-preview-sidebar-grid,
.polishpilot-preview-app-shell-grid {
  grid-template-columns: 1.35fr 0.75fr;
}
.polishpilot-preview-sidebar-grid .polishpilot-preview-card:first-child,
.polishpilot-preview-app-shell-grid .polishpilot-preview-card:first-child {
  grid-column: 1;
  grid-row: span 2;
}
.polishpilot-preview-kanban-grid,
.polishpilot-preview-card-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-centered-panel-grid {
  grid-template-columns: minmax(0, 0.72fr);
  justify-content: center;
}
.polishpilot-preview-nav-stack,
.polishpilot-preview-editorial-stack,
.polishpilot-preview-timeline-grid,
.polishpilot-preview-tabs-grid {
  grid-template-columns: minmax(0, 1fr);
}
.polishpilot-preview-nav-stack .polishpilot-preview-card:first-child,
.polishpilot-preview-tabs-grid .polishpilot-preview-card:first-child {
  min-height: 72px;
}
.polishpilot-preview-footer-grid {
  grid-template-columns: 1.25fr repeat(3, minmax(0, 0.8fr));
}
.polishpilot-preview-logo-grid {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}
.polishpilot-preview-timeline-grid {
  border-left: 2px solid var(--pp-accent-color, #10b981);
  padding-left: 18px;
}
.polishpilot-preview-timeline-grid .polishpilot-preview-card::before {
  content: "";
  position: absolute;
  left: -25px;
  top: 22px;
  width: 10px;
  height: 10px;
  border-radius: 999px;
  background: var(--pp-accent-color, #10b981);
}
.polishpilot-preview-generic-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-price,
.polishpilot-preview-stat-value {
  margin-top: 16px;
  font-size: clamp(28px, 4vw, 48px);
  line-height: 1;
  font-weight: 900;
}
.polishpilot-preview-stat-label {
  margin-top: 10px;
}
@media (max-width: 768px) {
  .polishpilot-preview-root,
  .polishpilot-preview-section {
    padding: 28px;
  }
  .polishpilot-preview-grid,
  .polishpilot-preview-bento-grid,
  .polishpilot-preview-featured-side-stack,
  .polishpilot-preview-center-highlight,
  .polishpilot-preview-step-grid,
  .polishpilot-preview-pricing-grid,
  .polishpilot-preview-split-grid,
  .polishpilot-preview-form-grid,
  .polishpilot-preview-product-preview-grid,
  .polishpilot-preview-metric-grid,
  .polishpilot-preview-comparison-grid,
  .polishpilot-preview-sidebar-grid,
  .polishpilot-preview-kanban-grid,
  .polishpilot-preview-app-shell-grid,
  .polishpilot-preview-centered-panel-grid,
  .polishpilot-preview-nav-stack,
  .polishpilot-preview-footer-grid,
  .polishpilot-preview-card-grid,
  .polishpilot-preview-timeline-grid,
  .polishpilot-preview-tabs-grid,
  .polishpilot-preview-logo-grid,
  .polishpilot-preview-editorial-stack,
  .polishpilot-preview-generic-grid {
    grid-template-columns: 1fr;
  }
  .polishpilot-preview-bento-grid .polishpilot-preview-card-featured,
  .polishpilot-preview-center-highlight .polishpilot-preview-card:first-child,
  .polishpilot-preview-sidebar-grid .polishpilot-preview-card:first-child,
  .polishpilot-preview-app-shell-grid .polishpilot-preview-card:first-child {
    grid-column: auto;
    grid-row: auto;
    max-width: none;
  }
}`}function N(e,t,i,r){const o=Number.parseFloat(e??"");return Number.isFinite(o)?`${Math.max(t,Math.min(i,o))}px`:r}function K(e,t){const i=e?.split(/\s+/).filter(Boolean);return i?.length?i.slice(0,4).map(r=>N(r,10,36,t)).join(" "):t}function v(e){return Object.entries(e).filter(t=>!!t[1]).map(([t,i])=>`${t}: ${ye(i)};`).join(" ")}function p(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function ve(e){return p(e).replace(/'/g,"&#39;")}function ye(e){return e.replace(/[<>"']/g,"")}function xe(e,t){const i=Array.isArray(e)?e:[],r=i.filter(Ne),o=i.filter(_),s=i.filter(Y),n=i.filter(Ee),l=i.filter(je),d=$(i.filter(Re),12),h=He(i),f=$(i.filter(Le),8),g=$(i.filter(De),12),b=$(i.filter(Q=>R(Q.text)>=34),8,180),c=ze({cards:s,actions:o,metricsCount:d.length}),m=Ie(i),a=Be(i),x=Fe(i);return{summary:{totalElements:t?.totalElements??i.length,headings:r.length||t?.headings||0,actions:o.length||t?.buttons||0,cards:s.length||t?.cardsEstimate||0,inputs:n.length||t?.inputs||0,media:l.length||(t?t.images+t.svgs:0),metrics:d.length,priceTokens:h.length,testimonials:f.length,navItems:g.length,longTextBlocks:b.length},primaryHeading:r.sort(S)[0]?.text.trim(),headings:$(r.sort(S),10,140),actions:o.sort(S).slice(0,12).map(M),cards:s.sort(S).slice(0,16).map(M),inputs:n.slice(0,12).map(M),media:l.sort(S).slice(0,12).map(M),metrics:d,priceTokens:h,testimonials:f,navItems:g,longTextBlocks:b,repeatedGroups:c,styleSignals:m,layoutSignals:a,keywords:x}}function V(e){const t=xe(e.matchedElements,e.counts),i=$e(e.selectedSourceSection,e.sourceSections);if(!i.length)return t;const r=Se(i,e.counts),o=i.flatMap(a=>[a.textSummary,...a.headingSnippets,...a.ctaSnippets,...a.mediaSnippets,a.className??"",a.id??"",a.role??"",a.ariaLabel??""]).join(" "),s=u(i.flatMap(a=>a.headingSnippets),12),n=i.flatMap(a=>a.ctaSnippets.slice(0,8).map(x=>I(a,x,"button"))),l=i.flatMap(a=>a.mediaSnippets.slice(0,8).map(x=>I(a,x,"media"))),d=ke(o,12),h=Me(o,16),f=/testimonial|review|rating|stars?|customer|founder|ceo|loved|trusted|quote/i.test(o)?u(i.map(a=>a.textSummary),8,160):[],g=i.some(a=>a.tagName==="nav"||/\b(nav|menu|navbar|navigation)\b/i.test(`${a.className??""} ${a.id??""} ${a.role??""}`))?u(i.flatMap(a=>[a.textSummary,...a.ctaSnippets]),16,64):[],b=Pe(o),c=Ce(i,r.cardsEstimate),m=[...t.repeatedGroups];return r.cardsEstimate>=3&&!m.some(a=>a.type==="card")&&m.push({type:"card",count:r.cardsEstimate,averageWidth:Math.round(i[0]?.rect.width??0),averageHeight:Math.round((i[0]?.rect.height??0)/Math.max(r.cardsEstimate,1)),similarSize:!0}),{...t,summary:{totalElements:Math.max(t.summary.totalElements,r.totalElements),headings:Math.max(t.summary.headings,r.headings,s.length),actions:Math.max(t.summary.actions,r.buttons,n.length),cards:Math.max(t.summary.cards,r.cardsEstimate),inputs:Math.max(t.summary.inputs,r.inputs),media:Math.max(t.summary.media,r.images+r.svgs,l.length),metrics:Math.max(t.summary.metrics,d.length),priceTokens:Math.max(t.summary.priceTokens,h.length),testimonials:Math.max(t.summary.testimonials,f.length),navItems:Math.max(t.summary.navItems,g.length),longTextBlocks:Math.max(t.summary.longTextBlocks,i.filter(a=>R(a.textSummary)>=34).length)},primaryHeading:t.primaryHeading??s[0],headings:u([...t.headings,...s],12),actions:E([...t.actions,...n],14),cards:E([...t.cards,...c],18),inputs:t.inputs,media:E([...t.media,...l],14),metrics:u([...t.metrics,...d],14),priceTokens:u([...t.priceTokens,...h],18),testimonials:u([...t.testimonials,...f],10,160),navItems:u([...t.navItems,...g],16,64),longTextBlocks:u([...t.longTextBlocks,...i.filter(a=>R(a.textSummary)>=34).map(a=>a.textSummary)],10,180),repeatedGroups:m,keywords:u([...t.keywords,...b],20)}}function $e(e,t){return e?[e]:(t??[]).slice(0,3)}function Se(e,t){const i=t??{totalElements:0,headings:0,buttons:0,links:0,images:0,svgs:0,inputs:0,cardsEstimate:0,textLength:0};return e.reduce((r,o)=>({totalElements:Math.max(r.totalElements,o.counts.totalElements),headings:Math.max(r.headings,o.counts.headings),buttons:Math.max(r.buttons,o.counts.buttons),links:Math.max(r.links,o.counts.links),images:Math.max(r.images,o.counts.images),svgs:Math.max(r.svgs,o.counts.svgs),inputs:Math.max(r.inputs,o.counts.inputs),cardsEstimate:Math.max(r.cardsEstimate,o.counts.cardsEstimate),textLength:Math.max(r.textLength,o.counts.textLength)}),i)}function I(e,t,i){return{label:C(y(t),120)||i,tagName:i,role:i==="button"?"button":e.role,className:e.className,width:Math.round(e.rect.width),height:Math.round(e.rect.height),top:Math.round(e.rect.top),left:Math.round(e.rect.left)}}function Ce(e,t){if(t<=0)return[];const i=e[0];if(!i)return[];const r=u([...i.headingSnippets,...i.textSummary.split(new RegExp("(?<=[.!?])\\s+|\\s{2,}")).map(o=>o.trim()).filter(Boolean)],Math.min(t,8),120);return Array.from({length:Math.min(t,8)},(o,s)=>({label:r[s]??`Card ${s+1}`,tagName:"card",role:null,className:i.className,width:Math.round(i.rect.width/Math.min(t,3)),height:Math.round(i.rect.height/Math.ceil(t/3)),top:Math.round(i.rect.top),left:Math.round(i.rect.left)}))}function E(e,t){const i=new Set,r=[];for(const o of e){const s=`${o.tagName}:${o.label}`;if(!i.has(s)&&(i.add(s),r.push(o),r.length>=t))break}return r}function u(e,t,i=120){const r=new Set,o=[];for(const s of e){const n=C(y(s),i);if(!(!n||r.has(n))&&(r.add(n),o.push(n),o.length>=t))break}return o}function ke(e,t){const i=e.match(/\b\d+(?:[.,]\d+)?(?:[%+$]|k|m|b|x| hrs?| min| sec| users?| teams?| credits?)\b/gi)??[];return u(i,t,80)}function Me(e,t){const i=e.match(/\$\s?\d+(?:[.,]\d+)?|\b\d+\s?(?:credits?|seats?|users?)\b|\b(?:free|pro|starter|enterprise|month|year|monthly|yearly|billing|plan)\b/gi)??[];return u(i,t,80)}function Pe(e){return["pricing","credits","plan","billing","feature","workflow","testimonial","review","dashboard","metric","analytics","form","email","password","waitlist","contact","settings","footer","navigation","cta","steps","process"].filter(i=>new RegExp(`\\b${i}\\b`,"i").test(e))}function M(e){return{label:Te(e),tagName:e.tagName,role:e.role,className:e.className,width:Math.round(e.rect.width),height:Math.round(e.rect.height),top:Math.round(e.rect.top),left:Math.round(e.rect.left)}}function Te(e){const t=y(e.text);return t?C(t,120):e.ariaLabel?C(e.ariaLabel,120):e.id?`#${e.id}`:e.className?`.${e.className.split(/\s+/).filter(Boolean).slice(0,2).join(".")}`:e.tagName}function Ne(e){const t=e.tagName.toLowerCase();if(/^h[1-6]$/.test(t)||e.role==="heading")return!0;const i=X(e.style.fontSize),r=J(e.style.fontWeight);return y(e.text).length>0&&i>=22&&r>=600}function _(e){const t=e.tagName.toLowerCase(),i=y(e.text),r=`${e.id??""} ${e.className??""} ${e.role??""} ${e.ariaLabel??""}`.toLowerCase(),o=e.rect.width>=44&&e.rect.width<=320&&e.rect.height>=26&&e.rect.height<=84;return t==="button"||e.role==="button"||t==="a"&&i.length>0&&i.length<=72||o&&/\b(btn|button|cta|action|submit|start|get|try|buy|book|join|sign|contact|demo|download)\b/i.test(`${r} ${i}`)}function Ee(e){return["input","textarea","select"].includes(e.tagName.toLowerCase())}function je(e){const t=e.tagName.toLowerCase(),i=`${e.id??""} ${e.className??""} ${e.ariaLabel??""}`.toLowerCase();return["img","svg","picture","video","canvas"].includes(t)||/\b(image|media|visual|mockup|preview|screenshot|chart|graph|illustration)\b/i.test(i)}function Y(e){const t=e.tagName.toLowerCase(),i=`${e.id??""} ${e.className??""} ${e.role??""} ${e.ariaLabel??""}`.toLowerCase(),r=D(e.style.backgroundColor)||D(e.style.borderColor)||e.style.boxShadow!=="none"||z(e.style.borderRadius)>0,o=e.rect.width>=96&&e.rect.height>=56&&e.rect.width<=820&&e.rect.height<=820&&r;return["article","li"].includes(t)||/\b(card|feature|tile|item|step|plan|price|testimonial|review|metric|stat|panel|box|cell|widget)\b/i.test(i)||o}function De(e){const t=e.tagName.toLowerCase(),i=`${e.id??""} ${e.className??""} ${e.role??""}`.toLowerCase(),r=y(e.text);return r.length>0&&r.length<=48&&(t==="a"||/\b(nav|menu|link|tab)\b/i.test(i))}function Re(e){return/\b\d+(?:[.,]\d+)?(?:[%+$]|k|m|b|x| hrs?| min| sec| users?| teams?| credits?)\b/i.test(e.text)}function Le(e){return/\b(testimonial|review|rating|stars?|customer|founder|ceo|loved|trusted|quote)\b/i.test(`${e.text} ${e.className??""} ${e.ariaLabel??""}`)}function He(e){const t=new Set;return e.forEach(i=>{(i.text.match(/\$\s?\d+(?:[.,]\d+)?|\b\d+\s?(?:credits?|seats?|users?)\b|\b(?:free|pro|starter|enterprise|month|year|monthly|yearly|billing|plan)\b/gi)??[]).forEach(s=>t.add(s.trim()))}),Array.from(t).slice(0,16)}function $(e,t,i=120){const r=new Set,o=[];for(const s of e){const n=y(s.text||s.ariaLabel||"");if(!(!n||r.has(n))&&(r.add(n),o.push(C(n,i)),o.length>=t))break}return o}function ze({actions:e,cards:t,metricsCount:i}){const r=[],o=B(t,"card"),s=B(e,"action");return o&&r.push(o),s&&r.push(s),i>=3&&r.push({type:"metric",count:i,averageWidth:0,averageHeight:0,similarSize:!1}),r}function B(e,t){if(e.length<2)return null;const i=A(e.map(s=>s.rect.width)),r=A(e.map(s=>s.rect.height)),o=e.length>=3&&e.filter(s=>Math.abs(s.rect.width-i)<=Math.max(16,i*.18)&&Math.abs(s.rect.height-r)<=Math.max(16,r*.22)).length>=3;return{type:t,count:e.length,averageWidth:Math.round(i),averageHeight:Math.round(r),similarSize:o}}function Ie(e){return{largeRadiusCount:e.filter(t=>z(t.style.borderRadius)>=20).length,pillCount:e.filter(Ue).length,shadowCount:e.filter(t=>We(t.style.boxShadow)>16).length,glowCount:e.filter(t=>Ae(t.style.boxShadow)).length,filledSurfaceCount:e.filter(t=>D(t.style.backgroundColor)).length}}function Be(e){if(!e.length)return{boundsWidth:0,boundsHeight:0,density:"sparse",columnsEstimate:0,rowsEstimate:0};const t=Math.min(...e.map(c=>c.rect.left)),i=Math.max(...e.map(c=>c.rect.right)),r=Math.min(...e.map(c=>c.rect.top)),o=Math.max(...e.map(c=>c.rect.bottom)),s=i-t,n=o-r,l=Math.max(s*n,1),h=e.reduce((c,m)=>c+m.rect.width*m.rect.height,0)/l,f=h>1.8?"dense":h<.45?"sparse":"balanced",g=U(e.map(c=>Ge(c)),48),b=U(e.map(c=>Oe(c)),48);return{boundsWidth:Math.round(s),boundsHeight:Math.round(n),density:f,columnsEstimate:g,rowsEstimate:b}}function Fe(e){const t=e.map(r=>`${r.text} ${r.className??""} ${r.id??""}`).join(" ");return["pricing","credits","plan","billing","feature","workflow","testimonial","review","dashboard","metric","analytics","form","email","password","waitlist","contact","settings","footer","navigation","cta"].filter(r=>new RegExp(`\\b${r}\\b`,"i").test(t)).slice(0,16)}function S(e,t){return F(t)-F(e)}function F(e){return X(e.style.fontSize)*6+J(e.style.fontWeight)/10+Math.sqrt(Math.max(e.rect.width*e.rect.height,0))+(_(e)?80:0)+(Y(e)?45:0)}function U(e,t){if(!e.length)return 0;const i=[...e].sort((s,n)=>s-n);let r=1,o=i[0];for(const s of i.slice(1))Math.abs(s-o)>t?(r+=1,o=s):o=(o+s)/2;return r}function D(e){return!(!e||e==="none"||e==="transparent"||/rgba?\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0\s*\)/i.test(e))}function Ue(e){const t=e.style.borderRadius??"";if(/9999px|50%/.test(t))return!0;const i=z(t),r=e.rect?.height??0;return i>=18&&r>0&&r<=72&&i>=r/2-2}function Ae(e){return!e||e==="none"?!1:(e.match(/rgba?\([^)]*\)|#[0-9a-f]{3,8}|hsla?\([^)]*\)/gi)??[]).some(i=>{const r=qe(i);return!r||r.a!==void 0&&r.a<.05?!1:Math.max(r.r,r.g,r.b)-Math.min(r.r,r.g,r.b)>=40})}function We(e){if(!e||e==="none")return 0;const t=e.split(/,(?![^()]*\))/);let i=0;for(const r of t){const s=(r.match(/-?\d+(?:\.\d+)?px/g)??[]).map(n=>Number.parseFloat(n))[2]??0;s>i&&(i=s)}return i}function z(e){if(!e)return 0;if(/\d+%/.test(e))return Number.parseFloat(e)>=40?999:0;const t=(e.match(/-?\d+(?:\.\d+)?/g)??[]).map(Number);return t.length?Math.max(...t):0}function X(e){if(!e)return 0;const t=e.match(/-?\d+(?:\.\d+)?/);return t?Number.parseFloat(t[0]):0}function J(e){if(!e)return 400;if(e==="bold")return 700;if(e==="normal")return 400;const t=Number.parseInt(e,10);return Number.isFinite(t)?t:400}function qe(e){if(!e)return null;const t=e.match(/rgba?\((\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?)(?:,\s*([0-9.]+))?\)/i);if(t)return{r:Number(t[1]),g:Number(t[2]),b:Number(t[3]),a:t[4]!==void 0?Number(t[4]):1};const i=e.match(/#([0-9a-f]{3}|[0-9a-f]{6})\b/i);if(!i)return null;const r=i[1],o=r.length===3?r.split("").map(s=>`${s}${s}`).join(""):r;return{r:Number.parseInt(o.slice(0,2),16),g:Number.parseInt(o.slice(2,4),16),b:Number.parseInt(o.slice(4,6),16),a:1}}function Ge(e){return e.rect.left+e.rect.width/2}function Oe(e){return e.rect.top+e.rect.height/2}function A(e){return e.length?e.reduce((t,i)=>t+i,0)/e.length:0}function R(e){return e?e.trim().split(/\s+/).filter(Boolean).length:0}function y(e){return(e??"").replace(/\s+/g," ").trim()}function C(e,t){return e.length>t?`${e.slice(0,t)}...`:e}function ot(e){const t=e.aiResult?.sectionType??"unknown",i=e.aiResult?.layoutType??"unknown",r=e.designDirectionSelected??!!(e.templateReference||e.animationReference),o=Ke(e.uncodixify,e.includedUncodixifyRuleIds),s=Ze(e.capture),n=Qe(e.capture),l=[];l.push(`# Role

You are a senior frontend engineer and product UI designer working inside the user's existing codebase.`);const d=["This block was selected from the user's existing website/app.",`Section type: ${t}. Current layout: ${i}.`,"","Detected object inventory:",n,"","Current visual style to preserve:",s];return r&&d.push("","Selected design direction (inspiration only):",Je(e)),l.push(`# Context

${d.join(`
`)}`),l.push(`# Task

Humanize the selected block by fixing the detected UI-quality issues.
Make the changes visible enough that the selected block no longer reads as generic/generated.
Layout, hierarchy, spacing, card emphasis, container structure, and CTA treatment may change inside this selected block when those changes directly resolve the detected issues.
This is not a page-wide redesign. Keep the block's purpose, content, functionality, and brand identity.`),l.push(`# Detected Issues

${o.length?Ve(o):Xe()}`),l.push(`# Implementation Plan

${Ye(e.capture,o,e.aiResult??null)}`),l.push(`# Style Preservation Rules

${r?`Use the selected design direction as layout inspiration only.
Do not copy external assets, brands, logos, or exact code.
Preserve the product's existing visual identity unless a detected issue specifically requires changes.
Use the direction to make concrete structural improvements, not just cosmetic tweaks.`:`Do not change the core visual style of the existing UI.
Do not redesign this into a different template or change the brand.
Only fix the detected issues listed below.
Preserve colors, typography family, content meaning, and component identity, but adjust layout, hierarchy, spacing, containers, and emphasis as needed to resolve the issues.`}`),l.push(`# Constraints

- Do not rewrite visible text unless necessary.
- Do not change functionality.
- Do not change business logic.
- Do not remove important content.
- Do not change data fetching.
- Preserve accessibility.
- Use existing project components/tokens if present.
- Do not solve structural issues with copy-only or color-only tweaks.
- Prefer focused, visible changes inside the selected block over a full page redesign.${e.animationReference?`
- If adding motion, keep it subtle and respect prefers-reduced-motion.`:""}`),l.push(`# Expected Output

Modify the relevant UI code.
Make concrete code changes that visibly resolve each included issue.
For layout/card/hierarchy findings, change the composition or component structure enough for the improvement to be obvious.
Return a short summary of what changed.`),l.push(`# Self-check

Before finishing, verify:
- visible text is preserved;
- functionality is unchanged;
- only detected issues were addressed;
- existing brand/style was preserved unless a detected issue required a structural change;
- each included issue has a corresponding visible UI change;
- no external assets or copied designs were introduced.`),l.join(`

`)}function Ke(e,t){if(!e||!e.findings.length)return[];const i=t?new Set(t):null;return e.findings.filter(r=>!i||i.has(r.ruleId))}function Ve(e){return e.map((t,i)=>_e(t,i+1)).join(`

`)}function _e(e,t){const i=e.evidence[0]??"Detected during analysis.",r=[`${t}. ${e.title}`,`Category: ${e.category}`,`Evidence: ${i}`,`Why it matters: ${e.whyItFeelsAI??"Reads as generic AI-generated UI."}`,`Correction direction: ${e.recommendation}`];return e.betterDirection&&r.push(`Direction (not a forced value): ${e.betterDirection}`),r.join(`
`)}function Ye(e,t,i){const r=e?V(e):null,o=new Set(t.map(c=>c.ruleId)),s=new Set(t.map(c=>c.category)),n=[],l=r?.primaryHeading,d=r?.actions[0]?.label,h=r?.summary.cards??0,f=r?.summary.priceTokens??0,g=r?.repeatedGroups.find(c=>c.type==="card"),b=i?.sectionType??e?.detected?.sectionType??"unknown";return n.push("Locate the selected block in the codebase and preserve its existing content, data flow, and component API."),(b==="pricing"||f>=2)&&n.push("Restructure the pricing area around plan comparison: make one recommended plan visually dominant, keep secondary plans quieter, and align price, benefits, and CTA rows for fast scanning."),b==="features"&&(g||h>=3)&&n.push("Turn the repeated feature/workflow cards into a clearer story: vary emphasis, introduce a lead step or featured card, and group supporting steps so the section reads as designed rather than cloned."),(o.has("repetitive-equal-cards")||o.has("monotonous-section-rhythm")||s.has("layout")||s.has("cards"))&&n.push(`Rework the block structure, not just styles: ${g||h>=3?`turn the ${h||g?.count} similar card objects into a hierarchy with one featured item and supporting items.`:"create one clear focal area and group supporting content around it."}`),(o.has("weak-hierarchy")||s.has("typography"))&&n.push(`Strengthen hierarchy around ${l?`"${l}"`:"the primary heading"} using type scale, spacing, and visual grouping.`),(o.has("weak-primary-action")||o.has("hero-missing-primary-cta")||o.has("hero-competing-ctas")||s.has("buttons"))&&n.push(`Make ${d?`"${d}"`:"one action"} the clear primary action and demote competing actions to secondary/link treatment.`),(o.has("text-heavy-block")||s.has("copywriting"))&&n.push("Reduce scan friction: keep the text meaning, but break dense copy into short support text, bullets, or grouped details."),(s.has("radius")||s.has("shadow")||s.has("panels")||s.has("color")||o.has("generic-saas-composition"))&&n.push("Clean up generated-looking styling: reduce excessive radius/glow/glass/shadows and rely on spacing, borders, and hierarchy."),t.length&&n.length<3&&n.push("Apply each detected recommendation as a visible UI change inside the selected block, then verify the before/after difference."),t.length?n.map((c,m)=>`${m+1}. ${c}`).join(`
`):["1. Inspect the selected block and make only small cleanup changes if a clear issue exists.","2. Do not redesign the block or invent problems not visible in the UI."].join(`
`)}function Xe(){return`No strong AI/Codex UI issues were detected — the block looks human-designed.
Apply only minor cleanup if something is clearly off. Do not invent issues, and do not redesign the block.`}function Je(e){const t=[];return e.pattern&&t.push(`Layout pattern: ${e.pattern.name}
Use this only as structural inspiration: ${e.pattern.promptInstruction}`),e.templateReference&&t.push(`Template reference: ${e.templateReference.title} (${e.templateReference.source})
Use only as high-level visual inspiration. Do not copy code, assets, text, logos, or branding.`),e.animationReference&&t.push(`Animation idea: ${e.animationReference.title} (${e.animationReference.source})
Use only as motion inspiration. Keep it subtle and respect prefers-reduced-motion.`),t.length?t.join(`

`):"Use the selected direction as layout inspiration only. Do not copy external assets or code."}function Qe(e){if(!e)return"- No object inventory was captured. Use the visible screenshot and existing code structure.";const t=V(e),i=t.summary;return[`- Counts: ${i.headings} headings, ${i.actions} actions, ${i.cards} cards, ${i.inputs} inputs, ${i.media} media, ${i.metrics} metrics, ${i.priceTokens} price/pricing tokens.`,t.primaryHeading?`- Primary heading: ${t.primaryHeading}`:"",t.headings.length?`- Headings: ${t.headings.slice(0,5).join(" | ")}`:"",t.actions.length?`- Actions: ${t.actions.slice(0,6).map(o=>o.label).join(" | ")}`:"",t.cards.length?`- Card-like objects: ${t.cards.slice(0,8).map(o=>o.label).join(" | ")}`:"",t.metrics.length?`- Metrics: ${t.metrics.slice(0,8).join(" | ")}`:"",t.priceTokens.length?`- Pricing tokens: ${t.priceTokens.slice(0,10).join(" | ")}`:"",t.repeatedGroups.length?`- Repeated groups: ${t.repeatedGroups.slice(0,4).map(o=>`${o.count} ${o.type}${o.similarSize?" with similar size":""}`).join(" | ")}`:"",`- Style signals: ${t.styleSignals.largeRadiusCount} large-radius, ${t.styleSignals.pillCount} pill, ${t.styleSignals.shadowCount} heavy-shadow, ${t.styleSignals.glowCount} glow, ${t.styleSignals.filledSurfaceCount} filled-surface elements.`,`- Layout signals: ${t.layoutSignals.density} density, approx ${t.layoutSignals.columnsEstimate} columns x ${t.layoutSignals.rowsEstimate} rows.`].filter(Boolean).join(`
`)}function Ze(e){const t=e?.styleTokens;if(t)return`- Section background: ${t.section.background??"existing section background"}
- Text color: ${t.section.color??t.heading.color??"existing text color"}
- Muted text color: ${t.muted.color??t.body.color??"existing muted text color"}
- Card background: ${t.card.background??"existing card background"}
- Border / radius: ${t.card.border??t.card.borderColor??"existing border"} / ${t.card.borderRadius??"existing radius"}
- Font family: ${t.section.fontFamily??t.heading.fontFamily??"existing font family"}

Treat these as direction, not forced values. Preserve the visual language through the existing components and design tokens; do not paste extracted CSS wholesale.`;const i=e?.styleContext;return i?`- Theme: ${i.theme}
- Background: ${i.section.backgroundColor??"existing section background"}
- Card background: ${i.card.backgroundColor??"existing card background"}
- Text color: ${i.text.headingColor??i.section.color??"existing text color"}
- Accent color: ${i.accent.color??i.accent.backgroundColor??"existing accent color"}
- Border radius: ${i.card.borderRadius??i.section.borderRadius??"existing radius"}

Treat these as direction, not forced values.`:"Preserve the existing visual style from the component and design system."}export{P as a,rt as b,et as c,tt as d,xe as e,V as f,ot as g,it as h,T as s,w as t};
