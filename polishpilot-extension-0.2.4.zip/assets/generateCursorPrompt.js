function X(e,i,t={}){const r={...t,id:t.id??`${Date.now()}-${Math.random().toString(36).slice(2)}`,timestamp:t.timestamp??Date.now(),stage:e,message:i,htmlPreview:t.htmlPreview?p(d(t.htmlPreview),4e3):void 0,cssPreview:t.cssPreview?p(u(t.cssPreview),8e3):void 0,outputHtml:t.outputHtml?p(d(t.outputHtml),8e3):void 0,outputCss:t.outputCss?p(u(t.outputCss),8e3):void 0,warnings:t.warnings?.slice(0,20),errors:t.errors?.slice(0,20)};return C(r),r}function Z(e,i){return[...e??[],...i].slice(-100)}function I(e){return e.map(i=>({...i,htmlPreview:p(d(i.htmlPreview??""),4e3),cssPreview:p(u(i.cssPreview??""),8e3),outputHtml:p(d(i.outputHtml??""),8e3),outputCss:p(u(i.outputCss??""),8e3)}))}function p(e,i=4e3){return e?e.length<=i?e:`${e.slice(0,i)}

/* truncated: ${e.length-i} chars omitted */`:""}function d(e){return e.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi,"<script>[removed]<\/script>").replace(/\son\w+="[^"]*"/gi,"").replace(/\son\w+='[^']*'/gi,"").replace(/\son\w+=([^\s>]+)/gi,"").replace(/javascript:/gi,"blocked-javascript:")}function u(e){return e.replace(/url\([\s\S]*?\)/gi,"url([removed])").replace(/@import[^;]+;/gi,"/* @import removed */")}function C(e){S()&&(console.groupCollapsed(`[Design Humanizer Preview] ${e.stage}`),console.log(e.summary??{}),e.htmlPreview&&console.log("HTML:",e.htmlPreview),e.cssPreview&&console.log("CSS:",e.cssPreview),e.outputHtml&&console.log("Output HTML:",e.outputHtml),e.outputCss&&console.log("Output CSS:",e.outputCss),e.warnings?.length&&console.warn(e.warnings),e.errors?.length&&console.error(e.errors),console.groupEnd())}function S(){try{return!!import.meta.env?.DEV||globalThis.localStorage?.getItem("DH_PREVIEW_DEBUG")==="1"}catch{return!1}}const w=new Set(["metric-bento","hero-metric-support-stats","stats-highlight","analytics-overview","metric-trend-grid","stats-story-band"]),P=new Set(["plan-comparison-table","comparison-spec-table","comparison-matrix"]),D=new Set(["split-hero","split-cta","product-detail-split","checkout-summary-split","case-study-split","demo-panel-cta","before-after-hero","hero-dashboard-preview","hero-video-demo","hero-contained-card","hero-off-grid-visual"]),k=new Set(["form-benefits-sidebar","split-auth-proof","onboarding-checklist-form","profile-settings-form"]);function ee(e){const i=e.pattern.layoutPreviewType,t=R(e.content.items),r=`
<section class="polishpilot-preview-root polishpilot-preview-section polishpilot-pattern-${W(i)}" style="${N(e.styleTokens)}">
  ${T(e.content,e.styleTokens)}
  ${j(i,t,e.styleTokens)}
  ${F(e.content,e.styleTokens)}
</section>`;return{html:r,layoutCss:L(),debug:{patternId:e.pattern.id,patternName:e.pattern.name,rendererUsed:b(i),preservedClassCount:M(e.content),inlineFallbackUsed:!!e.styleTokens,generatedNodeCount:A(r)}}}function R(e){return e.length?e.slice(0,6):[{id:"fallback-1",title:"Card 1",description:"Extracted preview item"},{id:"fallback-2",title:"Card 2",description:"Extracted preview item"},{id:"fallback-3",title:"Card 3",description:"Extracted preview item"}]}function T(e,i){return!e.sectionEyebrow&&!e.sectionTitle&&!e.sectionSubtitle?"":`<div class="polishpilot-preview-header">
    ${e.sectionEyebrow?`<div class="polishpilot-preview-eyebrow" style="${x(i)}">${o(e.sectionEyebrow)}</div>`:""}
    ${e.sectionTitle?`<h2 class="polishpilot-preview-heading" style="${v(i)}">${o(e.sectionTitle)}</h2>`:""}
    ${e.sectionSubtitle?`<p class="polishpilot-preview-subtitle" style="${c(i,!0)}">${o(e.sectionSubtitle)}</p>`:""}
  </div>`}function j(e,i,t){return`<div class="polishpilot-preview-grid ${b(e)}">
    ${i.slice(0,6).map((s,a)=>z(s,a,e,t)).join(`
`)}
  </div>`}function z(e,i,t,r){const s=q(i,t),a=`polishpilot-preview-card${s?" polishpilot-preview-card-featured":""}`;return t==="pricing-emphasis"?H(e,i,a,r):w.has(t)?U(e,a,r):`<article class="${a}" style="${f(r,s)}">
    ${e.icon?.exists?E(r):""}
    ${e.eyebrow?`<div class="polishpilot-preview-card-eyebrow" style="${x(r)}">${o(e.eyebrow)}</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${y(r)}">${o(e.title)}</h3>
    ${e.description?`<p class="polishpilot-preview-card-text" style="${c(r,!0)}">${o(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${g(r)}">${o(e.cta)}</div>`:""}
  </article>`}function H(e,i,t,r){const s=i===1;return`<article class="${t}${s?" polishpilot-preview-card-featured":""}" style="${f(r,s)}">
    ${s?`<div class="polishpilot-preview-badge" style="${g(r)}">Recommended</div>`:""}
    <h3 class="polishpilot-preview-card-title" style="${y(r)}">${o(e.title)}</h3>
    ${e.value?`<div class="polishpilot-preview-price" style="${v(r)}">${o(e.value)}</div>`:""}
    ${e.description?`<p class="polishpilot-preview-card-text" style="${c(r,!0)}">${o(e.description)}</p>`:""}
    ${e.cta?`<div class="polishpilot-preview-card-cta" style="${g(r)}">${o(e.cta)}</div>`:""}
  </article>`}function U(e,i,t){return`<article class="${i}" style="${f(t)}">
    <div class="polishpilot-preview-stat-value" style="${v(t)}">${o(e.value??e.title)}</div>
    <div class="polishpilot-preview-stat-label" style="${c(t,!0)}">${o(e.value?e.title:e.description??"")}</div>
  </article>`}function E(e){return`<div class="polishpilot-preview-icon-placeholder" style="${O(e)}">·</div>`}function F(e,i){return!e.outsideText.length||B(e)?"":`<div class="polishpilot-preview-outside-text">
    ${e.outsideText.map(t=>`<p style="${c(i,!0)}">${o(t)}</p>`).join(`
`)}
  </div>`}function B(e){return!!(e.sectionEyebrow||e.sectionTitle||e.sectionSubtitle||e.items.length)}function b(e){return e==="bento-grid"?"polishpilot-preview-bento-grid":e==="featured-side-stack"?"polishpilot-preview-featured-side-stack":e==="center-highlight"?"polishpilot-preview-center-highlight":e==="workflow-feature-grid"||e==="step-flow"||e==="demo-steps-hero"?"polishpilot-preview-step-grid":e==="pricing-emphasis"||e==="pricing-toggle"?"polishpilot-preview-pricing-grid":P.has(e)?"polishpilot-preview-comparison-grid":D.has(e)?"polishpilot-preview-split-grid":e==="hero-product-preview"?"polishpilot-preview-product-preview-grid":k.has(e)?"polishpilot-preview-form-grid":w.has(e)?"polishpilot-preview-metric-grid":e==="activity-feed-sidebar"||e==="table-summary-rail"||e==="faq-sidebar"?"polishpilot-preview-sidebar-grid":e==="kanban-board"?"polishpilot-preview-kanban-grid":e==="settings-detail-pane"||e==="sidebar-app-shell"?"polishpilot-preview-app-shell-grid":e==="magic-link-panel"||e==="card-cta"||e==="hero-email-capture"||e==="hero-image-background"?"polishpilot-preview-centered-panel-grid":e==="command-center-nav"||e==="mega-menu-topbar"?"polishpilot-preview-nav-stack":e==="footer-link-hub"?"polishpilot-preview-footer-grid":e==="product-card-grid"||e==="resource-card-grid"||e==="quote-wall"?"polishpilot-preview-card-grid":e==="changelog-timeline"?"polishpilot-preview-timeline-grid":e==="feature-tabs"||e==="hero-tabs-preview"?"polishpilot-preview-tabs-grid":e==="integration-logo-grid"||e==="hero-logo-cloud"?"polishpilot-preview-logo-grid":e==="editorial-feature-stack"?"polishpilot-preview-editorial-stack":"polishpilot-preview-generic-grid"}function q(e,i){return e===0&&["bento-grid","featured-side-stack","center-highlight","hero-product-preview","metric-bento","hero-metric-support-stats","analytics-overview","product-detail-split","before-after-hero","quote-wall","case-study-split","stats-story-band"].includes(i)}function M(e){return[...e.rootClasses??[],...e.sectionTitleSourceClasses??[],...e.sectionSubtitleSourceClasses??[],...e.items.flatMap(i=>[...i.sourceClasses??[],...i.titleSourceClasses??[],...i.textSourceClasses??[],...i.buttonSourceClasses??[]])].length}function A(e){return e.match(/<([a-z][a-z0-9-]*)\b/gi)?.length??0}function N(e){const i=$(e?.section.padding,"48px");return n({background:e?.section.background,color:e?.section.color,"font-family":e?.section.fontFamily,padding:i,"--pp-section-bg":e?.section.background,"--pp-text":e?.heading.color??e?.section.color,"--pp-muted":e?.body.color,"--pp-card-bg":e?.card.background,"--pp-border":e?.card.borderColor,"--pp-radius":e?.card.borderRadius,"--pp-shadow":e?.card.boxShadow,"--pp-section-padding":i,"--pp-accent-color":e?.accentColor})}function v(e){return n({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":h(e?.heading.fontSize,24,56,"36px"),"font-weight":e?.heading.fontWeight,"line-height":"1.08","letter-spacing":e?.heading.letterSpacing})}function y(e){return n({color:e?.heading.color,"font-family":e?.heading.fontFamily,"font-size":h(e?.body.fontSize??e?.heading.fontSize,14,22,"16px"),"font-weight":e?.heading.fontWeight})}function c(e,i=!1){return n({color:i?e?.muted.color??e?.body.color:e?.body.color,"font-size":h(e?.body.fontSize,12,18,"14px"),"line-height":"1.45"})}function f(e,i=!1){return n({background:e?.card.background,border:i&&e?.accentColor?`1px solid ${e.accentColor}`:e?.card.border,"border-color":i?e?.accentColor??e?.card.borderColor:e?.card.borderColor,"border-radius":e?.card.borderRadius,"box-shadow":e?.card.boxShadow,padding:$(e?.card.padding,"24px")})}function g(e){return n({background:e?.button.background??e?.accentColor,color:e?.button.color,border:e?.button.border,"border-radius":e?.button.borderRadius,padding:e?.button.padding,"font-weight":e?.button.fontWeight})}function x(e){return n({color:e?.accentColor})}function O(e){return n({color:e?.accentColor,"border-color":e?.accentColor})}function L(){return`
.polishpilot-preview-root,
.polishpilot-preview-section {
  width: 100%;
  height: 100%;
  min-height: 0;
  padding: var(--pp-section-padding, 48px);
  overflow: hidden !important;
  display: flex !important;
  flex-direction: column;
  justify-content: center;
  position: relative !important;
  opacity: 1 !important;
  visibility: visible !important;
  background: var(--pp-section-bg, #ffffff);
  color: var(--pp-text, #111827);
}
.polishpilot-preview-header {
  max-width: 760px;
  margin-bottom: clamp(18px, 4%, 32px);
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-heading,
.polishpilot-preview-subtitle,
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-outside-text p {
  margin: 0;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
}
.polishpilot-preview-subtitle {
  margin-top: 12px;
  max-width: 760px;
}
.polishpilot-preview-eyebrow,
.polishpilot-preview-card-eyebrow {
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 800;
  font-size: 12px;
}
.polishpilot-preview-grid {
  display: grid !important;
  gap: clamp(12px, 2.4%, 20px);
  min-height: 0;
}
.polishpilot-preview-card {
  min-width: 0;
  overflow: hidden !important;
  border-style: solid;
  border-width: 1px;
  display: block !important;
  opacity: 1 !important;
  visibility: visible !important;
  position: relative !important;
  background: var(--pp-card-bg, #ffffff);
  color: var(--pp-text, #111827);
  border-color: var(--pp-border, #e5e7eb);
  border-radius: var(--pp-radius, 16px);
  box-shadow: var(--pp-shadow, none);
}
.polishpilot-preview-card-title,
.polishpilot-preview-card-text,
.polishpilot-preview-stat-label,
.polishpilot-preview-outside-text p {
  overflow-wrap: anywhere;
}
.polishpilot-preview-card-text {
  margin-top: 10px;
}
.polishpilot-preview-card-cta,
.polishpilot-preview-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-top: 16px;
}
.polishpilot-preview-badge {
  margin-top: 0;
  margin-bottom: 14px;
}
.polishpilot-preview-icon-placeholder {
  width: 36px;
  height: 36px;
  border: 2px solid var(--pp-accent-color, currentColor);
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 14px;
  opacity: 0.75;
}
.polishpilot-preview-outside-text {
  display: grid;
  gap: 10px;
  margin-top: 28px;
  max-width: 820px;
}
.polishpilot-preview-bento-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-bento-grid .polishpilot-preview-card-featured {
  grid-column: span 2;
  grid-row: span 2;
}
.polishpilot-preview-featured-side-stack,
.polishpilot-preview-metric-grid {
  grid-template-columns: 1.35fr 0.85fr;
}
.polishpilot-preview-featured-side-stack .polishpilot-preview-card:first-child,
.polishpilot-preview-metric-grid .polishpilot-preview-card:first-child {
  grid-row: span 2;
}
.polishpilot-preview-center-highlight {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-center-highlight .polishpilot-preview-card:first-child {
  grid-column: 1 / -1;
  max-width: 78%;
  justify-self: center;
}
.polishpilot-preview-step-grid,
.polishpilot-preview-pricing-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-comparison-grid {
  grid-template-columns: 0.9fr repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-split-grid,
.polishpilot-preview-form-grid,
.polishpilot-preview-product-preview-grid {
  grid-template-columns: 0.9fr 1.1fr;
  align-items: center;
}
.polishpilot-preview-sidebar-grid,
.polishpilot-preview-app-shell-grid {
  grid-template-columns: 1.35fr 0.75fr;
}
.polishpilot-preview-sidebar-grid .polishpilot-preview-card:first-child,
.polishpilot-preview-app-shell-grid .polishpilot-preview-card:first-child {
  grid-column: 1;
  grid-row: span 2;
}
.polishpilot-preview-kanban-grid,
.polishpilot-preview-card-grid {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.polishpilot-preview-centered-panel-grid {
  grid-template-columns: minmax(0, 0.72fr);
  justify-content: center;
}
.polishpilot-preview-nav-stack,
.polishpilot-preview-editorial-stack,
.polishpilot-preview-timeline-grid,
.polishpilot-preview-tabs-grid {
  grid-template-columns: minmax(0, 1fr);
}
.polishpilot-preview-nav-stack .polishpilot-preview-card:first-child,
.polishpilot-preview-tabs-grid .polishpilot-preview-card:first-child {
  min-height: 72px;
}
.polishpilot-preview-footer-grid {
  grid-template-columns: 1.25fr repeat(3, minmax(0, 0.8fr));
}
.polishpilot-preview-logo-grid {
  grid-template-columns: repeat(4, minmax(0, 1fr));
}
.polishpilot-preview-timeline-grid {
  border-left: 2px solid var(--pp-accent-color, #10b981);
  padding-left: 18px;
}
.polishpilot-preview-timeline-grid .polishpilot-preview-card::before {
  content: "";
  position: absolute;
  left: -25px;
  top: 22px;
  width: 10px;
  height: 10px;
  border-radius: 999px;
  background: var(--pp-accent-color, #10b981);
}
.polishpilot-preview-generic-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
.polishpilot-preview-price,
.polishpilot-preview-stat-value {
  margin-top: 16px;
  font-size: clamp(28px, 4vw, 48px);
  line-height: 1;
  font-weight: 900;
}
.polishpilot-preview-stat-label {
  margin-top: 10px;
}
@media (max-width: 768px) {
  .polishpilot-preview-root,
  .polishpilot-preview-section {
    padding: 28px;
  }
  .polishpilot-preview-grid,
  .polishpilot-preview-bento-grid,
  .polishpilot-preview-featured-side-stack,
  .polishpilot-preview-center-highlight,
  .polishpilot-preview-step-grid,
  .polishpilot-preview-pricing-grid,
  .polishpilot-preview-split-grid,
  .polishpilot-preview-form-grid,
  .polishpilot-preview-product-preview-grid,
  .polishpilot-preview-metric-grid,
  .polishpilot-preview-comparison-grid,
  .polishpilot-preview-sidebar-grid,
  .polishpilot-preview-kanban-grid,
  .polishpilot-preview-app-shell-grid,
  .polishpilot-preview-centered-panel-grid,
  .polishpilot-preview-nav-stack,
  .polishpilot-preview-footer-grid,
  .polishpilot-preview-card-grid,
  .polishpilot-preview-timeline-grid,
  .polishpilot-preview-tabs-grid,
  .polishpilot-preview-logo-grid,
  .polishpilot-preview-editorial-stack,
  .polishpilot-preview-generic-grid {
    grid-template-columns: 1fr;
  }
  .polishpilot-preview-bento-grid .polishpilot-preview-card-featured,
  .polishpilot-preview-center-highlight .polishpilot-preview-card:first-child,
  .polishpilot-preview-sidebar-grid .polishpilot-preview-card:first-child,
  .polishpilot-preview-app-shell-grid .polishpilot-preview-card:first-child {
    grid-column: auto;
    grid-row: auto;
    max-width: none;
  }
}`}function h(e,i,t,r){const s=Number.parseFloat(e??"");return Number.isFinite(s)?`${Math.max(i,Math.min(t,s))}px`:r}function $(e,i){const t=e?.split(/\s+/).filter(Boolean);return t?.length?t.slice(0,4).map(r=>h(r,10,36,i)).join(" "):i}function n(e){return Object.entries(e).filter(i=>!!i[1]).map(([i,t])=>`${i}: ${V(t)};`).join(" ")}function o(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function W(e){return o(e).replace(/'/g,"&#39;")}function V(e){return e.replace(/[<>"']/g,"")}function ie(e){const i=e.aiResult?.sectionType??e.capture?.detected.sectionType??"unknown",t=e.aiResult?.layoutType??e.capture?.detected.layoutType??"unknown",r=e.designDirectionSelected??!!(e.templateReference||e.animationReference),s=G(e.uncodixify,e.includedUncodixifyRuleIds),a=Q(e.capture),l=[];l.push(`# Role

You are a senior frontend engineer and product UI designer working inside the user's existing codebase.`);const m=["This block was selected from the user's existing website/app.",`Section type: ${i}. Current layout: ${t}.`,"","Current visual style to preserve:",a];return r&&m.push("","Selected design direction (inspiration only):",J(e)),l.push(`# Context

${m.join(`
`)}`),l.push(`# Task

Fix the detected UI-quality issues in the selected block.
This is not a redesign of the product. Only address the detected issues listed below while keeping the block's purpose and visual identity.`),l.push(`# Detected Issues

${s.length?K(s):Y()}`),l.push(`# Style Preservation Rules

${r?`Use the selected design direction as layout inspiration only.
Do not copy external assets, brands, logos, or exact code.
Preserve the product's existing visual identity unless a detected issue specifically requires changes.`:`Do not change the core visual style of the existing UI.
Do not redesign this into a different template.
Only fix the detected issues listed below.
Preserve current colors, typography, content structure, spacing rhythm, and component identity unless a detected issue specifically requires adjustment.`}`),l.push(`# Constraints

- Do not rewrite visible text unless necessary.
- Do not change functionality.
- Do not change business logic.
- Do not remove important content.
- Do not change data fetching.
- Preserve accessibility.
- Use existing project components/tokens if present.
- Prefer small targeted changes over a full redesign.${e.animationReference?`
- If adding motion, keep it subtle and respect prefers-reduced-motion.`:""}`),l.push(`# Expected Output

Modify the relevant UI code.
Keep the changes minimal, intentional, and consistent with the existing codebase.
Return a short summary of what changed.`),l.push(`# Self-check

Before finishing, verify:
- visible text is preserved;
- functionality is unchanged;
- only detected issues were addressed;
- existing style was preserved unless a detected issue required a change;
- no external assets or copied designs were introduced.`),l.join(`

`)}function G(e,i){if(!e||!e.findings.length)return[];const t=i?new Set(i):null;return e.findings.filter(r=>!t||t.has(r.ruleId))}function K(e){return e.map((i,t)=>_(i,t+1)).join(`

`)}function _(e,i){const t=e.evidence[0]??"Detected during analysis.",r=[`${i}. ${e.title}`,`Category: ${e.category}`,`Evidence: ${t}`,`Why it matters: ${e.whyItFeelsAI??"Reads as generic AI-generated UI."}`,`Correction direction: ${e.recommendation}`];return e.betterDirection&&r.push(`Direction (not a forced value): ${e.betterDirection}`),r.join(`
`)}function Y(){return`No strong AI/Codex UI issues were detected — the block looks human-designed.
Apply only minor cleanup if something is clearly off. Do not invent issues, and do not redesign the block.`}function J(e){const i=[];return e.pattern&&i.push(`Layout pattern: ${e.pattern.name}
Use this only as structural inspiration: ${e.pattern.promptInstruction}`),e.templateReference&&i.push(`Template reference: ${e.templateReference.title} (${e.templateReference.source})
Use only as high-level visual inspiration. Do not copy code, assets, text, logos, or branding.`),e.animationReference&&i.push(`Animation idea: ${e.animationReference.title} (${e.animationReference.source})
Use only as motion inspiration. Keep it subtle and respect prefers-reduced-motion.`),i.length?i.join(`

`):"Use the selected direction as layout inspiration only. Do not copy external assets or code."}function Q(e){const i=e?.styleTokens;if(i)return`- Section background: ${i.section.background??"existing section background"}
- Text color: ${i.section.color??i.heading.color??"existing text color"}
- Muted text color: ${i.muted.color??i.body.color??"existing muted text color"}
- Card background: ${i.card.background??"existing card background"}
- Border / radius: ${i.card.border??i.card.borderColor??"existing border"} / ${i.card.borderRadius??"existing radius"}
- Font family: ${i.section.fontFamily??i.heading.fontFamily??"existing font family"}

Treat these as direction, not forced values. Preserve the visual language through the existing components and design tokens; do not paste extracted CSS wholesale.`;const t=e?.styleContext;return t?`- Theme: ${t.theme}
- Background: ${t.section.backgroundColor??"existing section background"}
- Card background: ${t.card.backgroundColor??"existing card background"}
- Text color: ${t.text.headingColor??t.section.color??"existing text color"}
- Accent color: ${t.accent.color??t.accent.backgroundColor??"existing accent color"}
- Border radius: ${t.card.borderRadius??t.section.borderRadius??"existing radius"}

Treat these as direction, not forced values.`:"Preserve the existing visual style from the component and design system."}export{d as a,ee as b,X as c,Z as d,I as e,ie as g,u as s,p as t};
